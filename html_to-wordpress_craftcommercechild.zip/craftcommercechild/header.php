<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> >
<header>
  <div class="header">
    <div class="container">
	  	<div id="mySidenav" class="sidenav hidden-lg hidden-md hidden-sm">
		  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		  <div class="logo mobile-logo">
          <h1><a href="<?php echo site_url(); ?>">
          <?php $logo = get_field('logo', 'option'); ?>
          <?php if($logo){ ?>
          <img src="<?php echo $logo; ?>" alt="Craft and Commerce"/></a></h1>
          <?php } ?>
          </div>
		  <?php $walker = new Menu_With_Description; ?>
		  <?php wp_nav_menu( array( 'menu' => 'mobile', 'container' => '', 'walker' => $walker ) ); ?>
		</div>
		<span style="font-size:43px;cursor:pointer" onclick="openNav()" class="hidden-lg hidden-md hidden-sm new">&#9776;</span>	
      
		
	  <div id="dSidenav" class="dsidenav hidden-xs">
		  <a href="javascript:void(0)" class="closebtn" onclick="closeDav()">&times;</a>
		  <div class="logo">
			<h1><a href="<?php echo site_url(); ?>">
			  <?php $logo = get_field('logo', 'option'); ?>
			  <?php if($logo){ ?>
			  <img src="<?php echo $logo; ?>" alt="Craft and Commerce"/></a></h1>
			  <?php } ?>
		  </div>
		  <?php $walker = new Menu_With_Description; ?>
		  <?php wp_nav_menu( array( 'menu' => 'mobile', 'container' => '', 'walker' => $walker ) ); ?>
	  </div>	
      <div class="main-menu hidden-xs">
      <span style="font-size:43px;cursor:pointer" onclick="openDav()" class="">&#9776;</span>  
      </div>
	  <div class="logo">
        <h1><a href="<?php echo site_url(); ?>">
          <?php $logo = get_field('logo', 'option'); ?>
          <?php if($logo){ ?>
          <img src="<?php echo $logo; ?>" alt="Craft and Commerce"/></a></h1>
          <?php } ?>
      </div>	
	  		
    </div>
  </div>
</header>
