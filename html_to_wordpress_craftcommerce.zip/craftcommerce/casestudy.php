<?php 
/* Template Name: Case Study */ 

get_header();
while ( have_posts() ) : the_post();
?>
<div class="case-study-title">
      <div class="study-title">
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
      </div>
</div>
<div class="outcome-section case-section">
  <div class="container">
    <div class="row loadMorePost" id="myList">
      <?php
        $terms = get_terms(array('taxonomy' => 'category')); 
        $args = array('post_type' => 'post', 'posts_per_page' => -1, 'order'=>'ASC','cat' => $term->ID);
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
        $post_featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
      ?>
      <div class="blog-single col-md-3 col-xs-12 col-sm-6">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $post_featured_img_url; ?>"></div>
            <div class="outcome-content"> 
            <?php 
              $categories = get_the_category($post->ID); 
              foreach ($categories as $category) { ?>
              <span class="tp-title">
                <?php echo $category->name;?>
              </span>
              <?php } ?>
              <?php $post_title_icon = get_field('post_title_icon', 'option'); ?>
              <div class="inn-title" style="background:url(<?php echo $post_title_icon; ?>);background-repeat: no-repeat !important;
            background-size: 23px !important;background-position: left center !important;"><span>DESIRED OUTCOME:</span>
              </div>
              <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
              <div class="social-media">
                <ul>
                  <?php
                  $post_social_share = get_field('post_social_share');
                  // echo '<pre>';
                  // print_r($social_share);
                  // echo '<pre>';
                  foreach($post_social_share as $post_social_shares){
                  ?>
                  <li><a href="<?php echo $post_social_shares['post_share_url']; ?>"><i class="<?php echo $post_social_shares['post_share_icon']; ?>"></i></a></li>
                   <?php } ?>    
                  <a class="compaign" href="<?php the_permalink(); ?>">VIEW CAMPAIGN</a>
                 
                </ul>
              </div>
            </div>
          </div>
        </div>   
      <?php endwhile;  wp_reset_query();?>
      </div>
	<div class="read-btn"><a href="javascript:void(0);" id="loadMore">Load More</a></div>
    </div>
</div>
<?php
endwhile; // End of the loop.
get_footer();
?>