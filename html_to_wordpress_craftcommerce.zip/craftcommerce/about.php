<?php 
/* Template Name: About */ 

get_header();
?>
<?php
while ( have_posts() ) : the_post();
$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
?>
	<div class="about-banner" style="background: #231f20 url(<?php echo $featured_img_url; ?>) top center no-repeat;background-size: 100%;">
    	<div class="container">
    	<h1><?php the_title(); ?></h1>
        <?php the_content(); ?>
		</div>
    </div>
    
    <div class="approch">
		<?php $section_title = get_field('section_title'); 
		$section_content = get_field('section_content');
		?>
    	<div class="container">
        	<div class=" title">
      			<h2><?php echo $section_title; ?></h2>
    		</div>
            <div class="app-bottom">
            	<ul>
					<?php foreach($section_content as $section){ ?>
                	<li><h4><?php echo $section['title']; ?></h4><span><?php echo $section['content']; ?></span></li>
					<?php } ?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="service-section">
  <div class="container">
    <div class="hm-title">
      <?php $os_ttile = get_field('os_ttile', 'option'); ?>
      <?php $os_background_image = get_field('os_background_image', 'option'); ?>
      <h4><?php echo $os_ttile; ?></h4>
    </div>
    <div class="row">
      <?php
        $args = array('post_type' => 'services', 'posts_per_page' => -1);
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
        
      ?>
        <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="service-box">

            <div class="img-place" style="background:url(<?php echo $os_background_image; ?>);background-repeat: no-repeat !important;
    background-position: center center !important;">             
            <img src="<?php echo $featured_img_url;?>"/> </div>
            <h3 class="serv-title"><?php the_title(); ?></h3>
            <p><?php the_content(); ?></p>
          </div>
        </div>
      
      <?php endwhile; wp_reset_query();?>
    </div>
  </div>
</div>
    
    <div class="logo-section logo-about">
  <div class="container">
    <div class="hm-title">
      <h4><?php $company_title = get_field('company_title', 'option'); ?><?php echo $company_title; ?></h4>
    </div>
    <ul>
      <?php
      $company_logos = get_field('company_logos','option');
      foreach($company_logos as $company_logo){
      ?>
      <li><img src="<?php echo $company_logo['logo']; ?>"/></li>
      <?php } ?>
    </ul>
  </div>
</div>

	<div class="about">
    	<div class="container">
        	<div class="about-title">
            	<div class="row">
                	<div class="col-md-12 col-xs-12 col-sm-12">
                    	<h1><?php $op_page_title = get_field('op_page_title', 'option'); ?><?php echo $op_page_title;?></h1>
                        <p><?php $op_page_description = get_field('op_page_description', 'option'); ?><?php echo $op_page_description;?></p>
                    </div>
                </div>
            </div>
            <div class="about-team">
				<?php
				$args = array('post_type' => 'ourteam', 'posts_per_page' => -1);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post();
				$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
				?>
                   <div class="about-inner">
                    <div class="about-img">
                        <img src="<?php echo $featured_img_url;?>">
                    </div>
                    <div class="team-des">
                        <h2><?php the_title(); ?></h2>
                        <?php $position = get_field('position', 'option'); ?>
                        <span><?php echo $position; ?></span>
                        <p><?php the_content(); ?></p>
                    </div>
                </div>

            <?php endwhile; wp_reset_query();?>
            </div>
        </div>
    </div>
<?php
endwhile; // End of the loop.
get_footer();
?>