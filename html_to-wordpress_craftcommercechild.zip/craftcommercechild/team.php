<?php 
/* Template Name: Our Team */ 

get_header();
?>
<div class="about">
    	<div class="container">
        	<div class="about-title">
            	<div class="row">
                	<div class="col-md-12 col-xs-12 col-sm-12">
                    	<h1><?php $op_page_title = get_field('op_page_title', 'option'); ?><?php echo $op_page_title;?></h1>
                        <p><?php $op_page_description = get_field('op_page_description', 'option'); ?><?php echo $op_page_description;?></p>
                    </div>
                </div>
            </div>
            <div class="about-team">
            	
            <?php
            $args = array('post_type' => 'ourteam', 'posts_per_page' => -1);
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');

            ?>
                <div class="about-inner">
                    <div class="about-img">
                        <img src="<?php echo $featured_img_url;?>">
                    </div>
                    <div class="team-des">
                        <h2><?php the_title(); ?></h2>
                        <?php $position = get_field('position'); ?>
                        <span><?php echo $position; ?></span>
                        <p><?php the_content(); ?></p>
                    </div>
                </div>

            <?php endwhile; wp_reset_query();?>
                    	
            </div>
        </div>
    </div>
<?php
get_footer();
?>