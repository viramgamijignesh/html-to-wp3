jQuery(window).on('load', function() {
jQuery("#myList .blog-single").slice(0, 8).show();
    jQuery("#loadMore").on('click', function (e) {
        e.preventDefault();
        jQuery("#myList .blog-single:hidden").slice(0, 8).slideDown();
        if (jQuery("#myList .blog-single:hidden").length == 0) {
            jQuery("#loadMore").fadeOut('slow');
        	jQuery('#loadMore').hide();
        }   
});
	
jQuery('.team-des').find('.expand').on('click', function (e) {
    e.preventDefault();
    this.expand = !this.expand;
    jQuery(this).text(this.expand?"READ LESS »":"READ MORE »");
    jQuery(this).closest('.team-des').find('.small, .big').toggleClass('small big');
});
	
});
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

function openDav() {
    document.getElementById("dSidenav").style.width = "100%";
}
function closeDav() {
    document.getElementById("dSidenav").style.width = "0";
}