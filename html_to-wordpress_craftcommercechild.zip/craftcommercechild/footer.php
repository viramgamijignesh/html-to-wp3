<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

?>
<footer>
  <div class="footer">
    <div class="newsletter-section">
      <div class="container">
        <div class="newsletter-box">
          <h3 class="plains-title"><?php $kt_title = get_field('kt_title', 'option'); ?><?php echo $kt_title; ?></h3>
          <p><?php $kt_description = get_field('kt_description', 'option'); ?><?php echo $kt_description; ?></p>
          <div class="news-right">
            <?php echo do_shortcode('[mc4wp_form id="149"]');?>
          </div>
        </div>
      </div>
    </div>
    <?php $footer_background_image = get_field('footer_background_image', 'option'); ?>
    
    <div class="footer-bottom" style="background:url(<?php echo $footer_background_image; ?>)no-repeat center center; background-size:cover;">
      <div class="container">
        <div class="footer-links">
          <ul>
            <?php wp_nav_menu( 
              array(
                'menu' => 'Footer'
              ) 
            );?>
          </ul>
        </div>
        <div class="footer-last">
          <div class="footer-logo"> 
            <?php $footer_logo = get_field('footer_logo', 'option'); ?>
            <img src="<?php echo $footer_logo; ?>"/> </div>
          <address>
          <?php $address = get_field('address', 'option'); ?>
          <?php echo $address; ?>
          </address>
          <div class="footer-social">
            <ul>
              <?php
              $footer_social_icons = get_field('footer_social_icons','option');
              foreach($footer_social_icons as $footer_social_icon){
              ?>
              <li>             
              <a href="<?php echo $footer_social_icon['link']; ?>"><i class="<?php echo $footer_social_icon['icon']; ?>"></i></a>              
              </li>              
               <?php } ?>    
            </ul>
            <?php $email = get_field('email', 'option'); ?>
            <a class="mail-link" href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a> </div>
          <p class="copyright"><?php $copy_rights = get_field('copy_rights', 'option'); ?><?php echo $copy_rights; ?></p>
        </div>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>