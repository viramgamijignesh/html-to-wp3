<?php 
/* Template Name: Contact Us */ 
get_header();
while ( have_posts() ) : the_post();
?>
<div class="contact-us" id="contact-us">
	<div class="container">
    	<div class="row">
        	<div class="col-md-6 col-xs-12 col-sm-6">
				<div class="map" id="map"></div>
			</div>
            <div class="col-md-6 col-xs-12 col-sm-6">
            	<div class="find-us">
                	<h1><?php $cf_title = get_field('cf_title', 'option'); ?><?php echo $cf_title;?></h1>                	
                	<?php $address = get_field('address', 'option'); ?>
                    <span><?php echo $address;?></span>
                    <div class="social-media">
                    	<?php
			              $footer_social_icons = get_field('footer_social_icons','option');
			              foreach($footer_social_icons as $footer_social_icon){
			            ?>
                    	<li><a href="<?php echo $footer_social_icon['link']; ?>"><i class="<?php echo $footer_social_icon['icon']; ?>"></i></a></li>               
                        <?php } ?>    
                    </div>
                    <div class="link"><a href="#"><?php $email = get_field('email', 'option'); ?><?php echo $email;?></a></div>
                    <p><?php $form_description = get_field('form_description', 'option'); ?><?php echo $form_description;?></h1></p>
                    <div class="form">
                    	<?php echo do_shortcode('[contact-form-7 id="93" title="Contact Form"]');?>
                    	<!-- <form>
                        	<input class="f-name" type="text" placeholder="FIRST NAME">
                            <input class="l-name" type="text" placeholder="LAST NAME">
                            <input class="email" type="text" placeholder="NAME@EMAIL.COM">
                            <textarea class="msg-box" type="text">YOUR MESSAGE HERE</textarea>
                        </form>
                        <button class="submit">SUBMIT</button> -->
                    </div>
                </div>
            </div>
			
        </div>
    </div>
			<div class="footer-image-contact">
			<?php
			$post_featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
			if($post_featured_img_url):	
			?>	
			<img src="<?php echo $post_featured_img_url; ?>" />
			<?php endif; ?>	
			</div>
</div>

<?php
$address = get_field('map', 'option');
$latlong    =   get_lat_long($address);
$latlong =  explode(',' ,$latlong);
$lat = $latlong[0]; //latitude value for mentioned address
$long = $latlong[1]; //longitude value for mentioned address
?>
<?php
endwhile; // End of the loop.
get_footer();
?>
<script>
google.maps.event.addDomListener(window, 'load', initialize);

jQuery(document).on('pageshow', '#contact-us', function(e, data){       
    initialize();
});	

function initialize() {
  var mapOptions = {
         zoom: 10,
               center: new google.maps.LatLng(40.6700, -73.9400), // New York
                  styles: [{"featureType":"administrative.land_parcel","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape.man_made","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"simplified"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"hue":"#f49935"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"hue":"#fad959"}]},{"featureType":"road.arterial","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"road.local","elementType":"labels","stylers":[{"visibility":"simplified"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"hue":"#a1cdfc"},{"saturation":30},{"lightness":49}]}]
              };
              var mapElement = document.getElementById('map');
	          var map = new google.maps.Map(mapElement, mapOptions);
	          var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(40.7107, -74.0081),
                    map: map,
                    title: '222 Broadway, 19th Floor New York, NY, 10038'
              });
}
</script>