<?php 
/* Template Name: Career */ 

get_header();
?>
<div class="inner-banner">
    <div class="container">
        <h1>Title of the Page</h1>
    </div>
</div>

<div class="bottom-content">
    <div class="container">
        <div class="top-section">
            <h2>Header style</h2>
            <span>Subhead Style</span>
            <p>Body copy style with <a href="#">Link Style</a> et ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br><br>

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
        </div>
        
        <blockquote>
            <h5>SUBHEAD STYLE</h5>
            <p>Item number one in a bulleted list.</p>
            <h5>SUBHEAD STYLE</h5>
            <p>Item number one in a bulleted list that is longer.</p>
        </blockquote>
        
        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>
        <button class="apply">APPLY HERE</button>
    </div>
</div>
<?php
get_footer();
?>