<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
<?php
/* Start the Loop */
while ( have_posts() ) : the_post();

$case_study_image_one = get_field('case_study_image_one');
$growth_title = get_field('growth_title');
$growth_link = get_field('growth_link');
$casy_study_growth_list = get_field('casy_study_growth_list');

$casy_study_image_two = get_field('casy_study_image_two');
$campaign_strategy_content = get_field('campaign_strategy_content');
$communications_director_content = get_field('communications_director_content');
$bottom_text = get_field('bottom_text');
?>
<div class="outcome-section case-section">
  <div class="container">
    
    <div class="row">
      <div class="col-md-12 col-xs-12 col-sm-6 first-col">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $case_study_image_one['url']; ?>">
          	 <span class="leaders">
          		<h1><?php 
              $categories = get_the_category(get_the_id()); 
              foreach ($categories as $category) { ?>
              <?php echo $category->name;?>
              <?php } ?></h1>
          </span>
          </div>
 
          <div class="outcome-content"> 
            <h1><?php the_title(); ?></h1>
            <div class="social-media">
                  <?php
				  $facebook = get_field('facebook');
				  $twitter = get_field('twitter');
				  $linkedin = get_field('linkedin');
				  $email = get_field('email');
				  $instagram = get_field('instagram');
				  ?>
				  <div class="a2a_kit a2a_kit_size_18 addtoany_list" data-a2a-url="<?php the_permalink(); ?>" data-a2a-title="<?php the_title(); ?>">
						<?php if($facebook){ ?>
					    <a class="a2a_button_facebook">
					    <img src="<?php echo get_stylesheet_directory_uri(); ?>/social/facebook.png">
					    </a>
					    <?php } if($twitter){ ?>
						<a class="a2a_button_twitter">
							<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/twitter.png">
					    </a>
					    <?php } if($linkedin){ ?>
						<a class="a2a_button_linkedin">
					  		<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/linkedin.png">  
					  	</a>
					    <?php } if($email){ ?>
						<a class="a2a_button_email">
					  		<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/email.png">
					    </a>
					    <?php } ?>
				 </div>
				 <div class="a2a_kit a2a_kit_size_18 a2a_follow addtoany_list custom-insta">
					  <?php if($instagram){ ?>
					  <a class="a2a_button_instagram" data-a2a-follow="craftandcommerce">
						  <img src="<?php echo get_stylesheet_directory_uri(); ?>/social/instagram.png">
					  </a>
					  <?php } ?>
				  </div>
              <span><a class="growth" href="<?php echo $growth_link; ?>"><?php echo $growth_title; ?></a></span>
            </div>
          </div>
		  <?php if(!empty(get_the_content())){ ?>	
          <div class="case-study-inner">
          		<?php the_content(); ?>
          </div>
		  <?php } ?>	
        <?php if($casy_study_growth_list){ ?>
        <div class="case-study-bottom">
        	<?php echo $casy_study_growth_list; ?>
        </div>
		<?php } ?>	
        </div>
      </div>
      
      <div class="col-md-12 col-xs-12 col-sm-6 second-col">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $casy_study_image_two['url']; ?>"></div>
		  <?php if($campaign_strategy_content){ ?>	
          <div class="stratagy">
          		<?php echo $campaign_strategy_content; ?>
          </div>
		  <?php } ?>	
		  <?php if($communications_director_content){ ?>	
          <div class="yellow-section">
          	<?php echo $communications_director_content; ?>
          </div>
		  <?php  } ?>	
          <div class="last-section">
          		<?php if($bottom_text){echo $bottom_text; } ?>
			  	<div class="back-btn buttons back-to-all">
					<a href="<?php echo site_url(); ?>/case-studies/">BACK TO ALL</a>
			    </div>	
                <?php
			    the_post_navigation( array(
					'screen_reader_text' =>' ',
					'prev_text' => '<div class="back-btn buttons">' . __( 'BACK TO ALL', 'twentyseventeen' ) . '</div>',
					'next_text' => '<div class="next-btn buttons">' . __( 'READ NEXT', 'twentyseventeen' ) . '</div>',
				) );
			    ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php 
endwhile; // End of the loop.

get_footer();
