<?php
/*--------------------css and js file-----------------------*/
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
function theme_enqueue_styles() {
	 wp_enqueue_style( 'bootstrap-style', get_stylesheet_directory_uri() . '/assets/css/bootstrap.css' );
	 wp_enqueue_style( 'fontawesome-style', get_stylesheet_directory_uri() . '/assets/css/fontawesome.css' );
	 wp_enqueue_style( 'iyr6qac-style', get_stylesheet_directory_uri() . '/assets/css/iyr6qac.css' );
	 
	 wp_enqueue_script( 'bootstrap-min', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js' );
	 wp_enqueue_script( 'googleapis', 'https://maps.googleapis.com/maps/api/js' );
	 wp_enqueue_script( 'custom', get_stylesheet_directory_uri() . '/assets/js/custom.js' );
}
/*------------------------theme options----------------------*/
if( function_exists('acf_add_options_sub_page') )
{   
    acf_add_options_sub_page( 'Home Page' );
	acf_add_options_sub_page( 'Contact Page' );
	acf_add_options_sub_page( 'Header' );
    acf_add_options_sub_page( 'Footer' );	
}
if( function_exists('acf_set_options_page_title') )
{
    acf_set_options_page_title( __('Theme Options') );
}
/*--------------service---------------------------*/
add_action( 'init', 'services_post_type' );
function services_post_type() {
    $labels = array(
        'name' => 'Our Services',
        'singular_name' => 'Services',
        'add_new' => 'Add New Services',
        'add_new_item' => 'Add New Services',
        'edit_item' => 'Edit Services',
        'new_item' => 'New Services',
        'view_item' => 'View Services',
        'search_items' => 'Search Services',
        'not_found' =>  'No Services found',
        'not_found_in_trash' => 'No Services in the trash',
		'featured_image' => __( 'Service Image' ),
		'set_featured_image' => __( 'Set Service Image' ),
		'remove_featured_image' => __( 'Remove Service Image' ),
		'use_featured_image' => __( 'Use as Service Image' )
    );
    register_post_type( 'services', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'thumbnail','editor' ),
  	) );
}
/*---------------our team------------------------*/
add_action( 'init', 'ourteam_post_type' );
function ourteam_post_type() {
    $labels = array(
        'name' => 'Our Team',
        'singular_name' => 'Team',
        'add_new' => 'Add New Team',
        'add_new_item' => 'Add New Team',
        'edit_item' => 'Edit Team',
        'new_item' => 'New Team',
        'view_item' => 'View Team',
        'search_items' => 'Search Teams',
        'not_found' =>  'No Team found',
        'not_found_in_trash' => 'No Team in the trash',
		'featured_image' => __( 'Team Image' ),
		'set_featured_image' => __( 'Set Team Image' ),
		'remove_featured_image' => __( 'Remove Team Image' ),
		'use_featured_image' => __( 'Use as Team Image' )
    );
    register_post_type( 'ourteam', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'thumbnail','editor' ),
  	) );
}
/*-------------------------our partner------------------------*/
add_action( 'init', 'ourpartner_post_type' );
function ourpartner_post_type() {
    $labels = array(
        'name' => 'Our Partner',
        'singular_name' => 'Partner',
        'add_new' => 'Add New Partner',
        'add_new_item' => 'Add New Partner',
        'edit_item' => 'Edit Partner',
        'new_item' => 'New Partner',
        'view_item' => 'View Partner',
        'search_items' => 'Search Partners',
        'not_found' =>  'No Partner found',
        'not_found_in_trash' => 'No Partner in the trash',
		'featured_image' => __( 'Partner Image' ),
		'set_featured_image' => __( 'Set Partner Image' ),
		'remove_featured_image' => __( 'Remove Partner Image' ),
		'use_featured_image' => __( 'Use as Partner Image' )
    );
    register_post_type( 'ourpartner', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'thumbnail','editor' ),
  	) );
}
/*-----------------------case study----------------------*/
add_action( 'init', 'case_studie_post_type' );
function case_studie_post_type() {
    $labels = array(
        'name' => 'Case Studies',
        'singular_name' => 'Case Study',
        'add_new' => 'Add New Case Study',
        'add_new_item' => 'Add New Case Study',
        'edit_item' => 'Edit Case Study',
        'new_item' => 'New Case Study',
        'view_item' => 'View Case Study',
        'search_items' => 'Search Case Studies',
        'not_found' =>  'No Case Study found',
        'not_found_in_trash' => 'No Case Study in the trash',
		'featured_image' => __( 'Case Study Image' ),
		'set_featured_image' => __( 'Set Case Study Image' ),
		'remove_featured_image' => __( 'Remove Case Study Image' ),
		'use_featured_image' => __( 'Use as Case Study Image' )
    );
    register_post_type( 'casestudie', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'thumbnail','editor' ),
  	) );
}
add_action( 'init', 'casestudie_category_tax' );
/*-------------------case study custom category----------------------------*/
function casestudie_category_tax() {
	register_taxonomy(
		'category',
		'casestudie',
		array(
			'label' => __( 'Category' ),
			'rewrite' => array( 'slug' => 'category' ),
			'hierarchical' => true,
		)
	);
}
/*------------------------client-------------------------------*/
add_action( 'init', 'client_post_type' );
function client_post_type() {
    $labels = array(
        'name' => 'Clients',
        'singular_name' => 'Client',
        'add_new' => 'Add New Client',
        'add_new_item' => 'Add New Client',
        'edit_item' => 'Edit Client',
        'new_item' => 'New Client',
        'view_item' => 'View Client',
        'search_items' => 'Search Clients',
        'not_found' =>  'No Client found',
        'not_found_in_trash' => 'No Client in the trash',
		'featured_image' => __( 'Client Image' ),
		'set_featured_image' => __( 'Set Client Image' ),
		'remove_featured_image' => __( 'Remove Client Image' ),
		'use_featured_image' => __( 'Use as Client Image' )
    );
    register_post_type( 'client', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'exclude_from_search' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 10,
        'supports' => array( 'title', 'thumbnail','editor' ),
  	) );
}
/*----------------span add in acf editor-----------------------*/
function override_mce_options($initArray) 
{
  $opts = '*[*]';
  $initArray['valid_elements'] = $opts;
  $initArray['extended_valid_elements'] = $opts;
  return $initArray;
 }
add_filter('tiny_mce_before_init', 'override_mce_options');
/*------------------------Menu description added------------------------*/
class Menu_With_Description extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth, $args) {
        global $wp_query;
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
        $class_names = $value = '';
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
        $class_names = ' class="' . esc_attr( $class_names ) . '"';
        $output .= $indent . '<li id="menu-item-'. $item->ID . '"' . $value . $class_names .'>';
        $attributes = ! empty( $item->attr_title ) ? ' title="' . esc_attr( $item->attr_title ) .'"' : '';
        $attributes .= ! empty( $item->target ) ? ' target="' . esc_attr( $item->target ) .'"' : '';
        $attributes .= ! empty( $item->xfn ) ? ' rel="' . esc_attr( $item->xfn ) .'"' : '';
        $attributes .= ! empty( $item->url ) ? ' href="' . esc_attr( $item->url ) .'"' : '';
        $item_output = $args->before;
        $item_output .= '<a'. $attributes .'>';
        $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
        $item_output .= '<span class="menu-content sub">' . $item->description . '</span>';
        $item_output .= '</a>';
        $item_output .= $args->after;
        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}
/*------------------content limit-----------------------*/
function custom_excerpt_length( $length ) {
	   return 30;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
/*-------------------read more link change--------------------------*/
function new_excerpt_more($more) {
  global $post;
  remove_filter('excerpt_more', 'new_excerpt_more'); 
  if(!wp_is_mobile() ) {
	return ' <a class="read_more" href="'. get_permalink($post->ID) . '">' . 'READ MORE »' . '</a>';
  }else{	
  	return '...';
  }	  
}
add_filter('excerpt_more','new_excerpt_more',11);
/*-------------------get lat and logi function----------------*/
function get_lat_long($address){
    $address = str_replace(" ", "+", $address);
    $json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&region=$region");
    $json = json_decode($json);
    $lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
    $long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
    return $lat.','.$long;
}