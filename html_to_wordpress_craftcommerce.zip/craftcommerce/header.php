<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CRAFT & COMMERCE</title>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/assets/css/fontawesome.css">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/style.css">
<link rel="stylesheet" href="https://use.typekit.net/iyr6qac.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/custom.js"></script>
</head>

<body <?php body_class(); ?> >
<header>
  <div class="header">
    <div class="container">
      <div class="logo">
        <h1><a href="<?php echo site_url(); ?>">
          <?php $logo = get_field('logo', 'option'); ?>
          <?php if($logo){ ?>
          <img src="<?php echo $logo; ?>" alt="LOGO"/></a></h1>
          <?php } ?>
      </div>
      <div class="main-menu">
        <?php wp_nav_menu( 
          array(
            'menu' => 'Header',
            'container' => 'ul'
          ) 
        );?>
      </div>
    </div>
  </div>
</header>
