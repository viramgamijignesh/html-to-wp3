<?php 
/* Template Name: Case Study */ 

get_header();
while ( have_posts() ) : the_post();
?>
<div class="case-study-title">
      <div class="study-title">
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
      </div>
</div>
<div class="outcome-section case-section">
  <div class="container">
    <div class="row loadMorePost" id="myList">
      <?php
        $terms = get_terms(array('taxonomy' => 'category')); 
        $args = array('post_type' => 'casestudie', 'posts_per_page' => -1, 'order'=>'DESC','cat' => $term->ID);
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
        $post_featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
		$enable_disable = get_field('enable_disable');
        if($enable_disable){
      ?>
      <div class="blog-single col-md-6 col-xs-12 col-sm-6">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $post_featured_img_url; ?>"></div>
            <div class="outcome-content"> 
            <?php 
              $categories = get_the_category($post->ID); 
              foreach ($categories as $category) { ?>
              <span class="tp-title">
                <?php echo $category->name;?>
              </span>
              <?php } ?>
              <?php $post_title_icon = get_field('post_title_icon', 'option'); ?>
              <div class="inn-title" style="background:url(<?php echo $post_title_icon; ?>);background-repeat: no-repeat !important;
            background-size: 23px !important;background-position: left center !important;"><span>DESIRED OUTCOME:</span>
              </div>
              <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
              <div class="social-media">
                  <?php
				  $facebook = get_field('facebook');
				  $twitter = get_field('twitter');
				  $linkedin = get_field('linkedin');
				  $email = get_field('email');
				  $instagram = get_field('instagram');
				  ?>
				  <div class="a2a_kit a2a_kit_size_18 addtoany_list" data-a2a-url="<?php the_permalink(); ?>" data-a2a-title="<?php the_title(); ?>">
						<?php if($facebook){ ?>
					    <a class="a2a_button_facebook">
					    <img src="<?php echo get_stylesheet_directory_uri(); ?>/social/facebook.png">
					    </a>
					    <?php } if($twitter){ ?>
						<a class="a2a_button_twitter">
							<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/twitter.png">
					    </a>
					    <?php } if($linkedin){ ?>
						<a class="a2a_button_linkedin">
					  		<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/linkedin.png">  
					  	</a>
					    <?php } if($email){ ?>
						<a class="a2a_button_email">
					  		<img src="<?php echo get_stylesheet_directory_uri(); ?>/social/email.png">
					    </a>
					    <?php } ?>
				 </div>
				 <div class="a2a_kit a2a_kit_size_18 a2a_follow addtoany_list custom-insta">
					  <?php if($instagram){ ?>
					  <a class="a2a_button_instagram" data-a2a-follow="craftandcommerce">
						  <img src="<?php echo get_stylesheet_directory_uri(); ?>/social/instagram.png">
					  </a>
					  <?php } ?>
				  </div>
				  <ul>
                  <a class="compaign" href="<?php the_permalink(); ?>">VIEW CAMPAIGN</a>
                 
                </ul>
              </div>
            </div>
          </div>
        </div>   
      <?php } endwhile;  wp_reset_query();?>
      </div>
	<div class="read-btn"><a href="javascript:void(0);" id="loadMore">Load More</a></div>
    </div>
</div>
<?php
endwhile; // End of the loop.
get_footer();
?>
