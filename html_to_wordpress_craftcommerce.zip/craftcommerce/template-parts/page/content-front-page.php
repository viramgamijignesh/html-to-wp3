<div class="banner">
  <div class="container">
    <div class="banner-content">
      <?php $banner_text = get_field('banner_text', 'option'); ?>
      <h1><?php echo $banner_text; ?></h1>
    </div>
  </div>
</div>
<?php $title_background_image = get_field('title_background_image', 'option'); ?>
<?php $our_mission_background_image = get_field('our_mission_background_image', 'option'); ?>
<?php $our_mission_title = get_field('our_mission_title', 'option'); ?>
<?php $our_mission_description = get_field('our_mission_description', 'option'); ?>
<div class="our-mission" style="background:url(<?php echo $our_mission_background_image; ?>);background-repeat:no-repeat;padding:70px 0;background-size: cover;text-align:center;">
  <div class="container">    
    <div class="title" style="background:url(<?php echo $title_background_image; ?>);background-repeat:no-repeat;background-position: top center;background-size:contain;">
      <h2><?php echo $our_mission_title; ?></h2>
    </div>
    <div class="mission-content"><?php echo $our_mission_description; ?></div>
  </div>
</div>
<div class="outcome-section">
  <div class="container">
    <div class="outcome-title">
      <div class="small-title">
        <?php $ds_title = get_field('ds_title', 'option'); ?>
        <h2><?php echo $ds_title ;?></h2>
      </div>
      <div class="main-title">
        <?php $ds_sub_title = get_field('ds_sub_title', 'option'); ?>
        <h1 class="line-title"><span><?php echo $ds_sub_title ;?></span></h1>
      </div>
    </div>
    <div class="row loadMorePost" id="myList">
      <?php
        $terms = get_terms(array('taxonomy' => 'category')); 
        $args = array('post_type' => 'post', 'posts_per_page' => -1, 'order'=>'ASC','cat' => $term->ID);
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
        $post_featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
      ?>

      <div class="blog-single col-md-3 col-xs-12 col-sm-6">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $post_featured_img_url; ?>"></div>
            <div class="outcome-content"> 
            <?php 
              $categories = get_the_category($post->ID); 
              foreach ($categories as $category) { ?>
              <span class="tp-title">
                <?php echo $category->name;?>
              </span>
              <?php } ?>
              <?php $post_title_icon = get_field('post_title_icon', 'option'); ?>
              <div class="inn-title" style="background:url(<?php echo $post_title_icon; ?>);background-repeat: no-repeat !important;
            background-size: 23px !important;background-position: left center !important;"><span>DESIRED OUTCOME:</span>
              </div>
              <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
              <div class="social-media">
                <ul>
                  <?php
                  $post_social_share = get_field('post_social_share','option');
                  // echo '<pre>';
                  // print_r($social_share);
                  // echo '<pre>';
                  foreach($post_social_share as $post_social_shares){
                  ?>
                  <li><a href="<?php echo $post_social_shares['post_share_url']; ?>"><i class="<?php echo $post_social_shares['post_share_icon']; ?>"></i></a></li>
                   <?php } ?>    
                  <a class="compaign" href="#">VIEW CAMPAIGN</a>
                 
                </ul>
              </div>
            </div>
          </div>
        </div>   
          <?php endwhile;  wp_reset_query();?>    
          
      </div>
    </div>
    <div class="read-btn"><a href="javascript:void(0);" id="loadMore">Load More</a></div>
  </div>
</div>
<div class="service-section">
  <div class="container">
    <div class="hm-title">
      <?php $os_ttile = get_field('os_ttile', 'option'); ?>
      <?php $os_background_image = get_field('os_background_image', 'option'); ?>
      <h4><?php echo $os_ttile; ?></h4>
    </div>
    <div class="row">
      <?php
        $args = array('post_type' => 'services', 'posts_per_page' => -1);
        $loop = new WP_Query( $args );
        while ( $loop->have_posts() ) : $loop->the_post();
        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
        
      ?>
        <div class="col-md-3 col-xs-12 col-sm-6">
          <div class="service-box">

            <div class="img-place" style="background:url(<?php echo $os_background_image; ?>);background-repeat: no-repeat !important;
    background-position: center center !important;">             
            <img src="<?php echo $featured_img_url;?>"/> </div>
            <h3 class="serv-title"><?php the_title(); ?></h3>
            <p><?php the_content(); ?></p>
          </div>
        </div>
      
      <?php endwhile; wp_reset_query();?>
    </div>
  </div>
</div>
<div class="logo-section logo-about">
  <div class="container">
    <div class="hm-title">
      <h4><?php $company_title = get_field('company_title', 'option'); ?><?php echo $company_title; ?></h4>
    </div>
    <ul>
      <?php
	  $company_logos = get_field('company_logos','option');
      foreach($company_logos as $company_logo){
      ?>
      <li><img src="<?php echo $company_logo['logo']; ?>"/></li>
      <?php } ?>    
    </ul>
  </div>
</div>