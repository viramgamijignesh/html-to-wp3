<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
<?php
/* Start the Loop */
while ( have_posts() ) : the_post();

$case_study_image_one = get_field('case_study_image_one');
$growth_title = get_field('growth_title');
$growth_link = get_field('growth_link');
$casy_study_growth_list = get_field('casy_study_growth_list');

$casy_study_image_two = get_field('casy_study_image_two');
$campaign_strategy_content = get_field('campaign_strategy_content');
$communications_director_content = get_field('communications_director_content');
$bottom_text = get_field('bottom_text');
?>
<div class="outcome-section case-section">
  <div class="container">
    
    <div class="row">
      <div class="col-md-6 col-xs-12 col-sm-6">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $case_study_image_one['url']; ?>">
          	 <span class="leaders">
          		<h1><?php the_category(); ?></h1>
          </span>
          </div>
 
          <div class="outcome-content"> 
            <h1><?php the_title(); ?></h1>
            <div class="social-media">
              <ul>
				  <?php
                  $post_social_share = get_field('post_social_share');
                  foreach($post_social_share as $post_social_shares){
                  ?>
                  <li><a href="<?php echo $post_social_shares['post_share_url']; ?>"><i class="<?php echo $post_social_shares['post_share_icon']; ?>"></i></a></li>
                  <?php } ?>
             
              </ul>
              <span><a class="growth" href="<?php echo $growth_link; ?>"><?php echo $growth_title; ?></a></span>
            </div>
          </div>
          <div class="case-study-inner">
          		<?php the_content(); ?>
          </div>
        <?php if($casy_study_growth_list){ ?>
        <div class="case-study-bottom">
        	<?php echo $casy_study_growth_list; ?>
        </div>
		<?php } ?>	
        </div>
      </div>
      
      <div class="col-md-6 col-xs-12 col-sm-6">
        <div class="outcom-box">
          <div class="outcome-img"><img src="<?php echo $casy_study_image_two['url']; ?>"></div>
		  <?php if($campaign_strategy_content){ ?>	
          <div class="stratagy">
          		<?php echo $campaign_strategy_content; ?>
          </div>
		  <?php } ?>	
		  <?php if($communications_director_content){ ?>	
          <div class="yellow-section">
          	<?php echo $communications_director_content; ?>
          </div>
		  <?php  } ?>	
          <div class="last-section">
          		<?php if($bottom_text){echo $bottom_text; } ?>
                <?php
			    the_post_navigation( array(
					'screen_reader_text' => ' ',
					'prev_text' => '<div class="back-btn buttons">' . __( 'BACK TO ALL', 'twentyseventeen' ) . '</div>',
					'next_text' => '<div class="next-btn buttons">' . __( 'READ NEXT', 'twentyseventeen' ) . '</div>',
				) );
			    ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php 
endwhile; // End of the loop.

get_footer();
