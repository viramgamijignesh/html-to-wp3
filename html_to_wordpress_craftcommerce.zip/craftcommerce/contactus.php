<?php 
/* Template Name: Contact Us */ 
get_header();
?>
<div class="contact-us">
	<div class="container">
    	<div class="row">
        	<div class="col-md-6 col-xs-12 col-sm-6">
            	<div class="map">
            		<?php $map = get_field('map', 'option'); ?>
            		
            		<iframe src="<?php echo $map;?>" width="100%" height="496" frameborder="0" style="border:0" allowfullscreen></iframe>              
            		
                </div>
            </div>
            <div class="col-md-6 col-xs-12 col-sm-6">
            	<div class="find-us">
                	<h1><?php $cf_title = get_field('cf_title', 'option'); ?><?php echo $cf_title;?></h1>                	
                	<?php $address = get_field('address', 'option'); ?>
                    <span><?php echo $address;?></span>
                    <div class="social-media">
                    	<?php
			              $footer_social_icons = get_field('footer_social_icons','option');
			              foreach($footer_social_icons as $footer_social_icon){
			            ?>
                    	<li><a href="<?php echo $footer_social_icon['link']; ?>"><i class="<?php echo $footer_social_icon['icon']; ?>"></i></a></li>               
                        <?php } ?>    
                    </div>
                    <div class="link"><a href="#"><?php $email = get_field('email', 'option'); ?><?php echo $email;?></a></div>
                    <p><?php $form_description = get_field('form_description', 'option'); ?><?php echo $form_description;?></h1></p>
                    <div class="form">
                    	<?php echo do_shortcode('[contact-form-7 id="93" title="Contact Form"]');?>
                    	<!-- <form>
                        	<input class="f-name" type="text" placeholder="FIRST NAME">
                            <input class="l-name" type="text" placeholder="LAST NAME">
                            <input class="email" type="text" placeholder="NAME@EMAIL.COM">
                            <textarea class="msg-box" type="text">YOUR MESSAGE HERE</textarea>
                        </form>
                        <button class="submit">SUBMIT</button> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer();
?>