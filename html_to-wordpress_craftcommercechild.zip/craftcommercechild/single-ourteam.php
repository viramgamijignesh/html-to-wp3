<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>
<?php
/* Start the Loop */
while ( have_posts() ) : the_post();
?>
<div class="inner-banner">
	<div class="container">
    	<h1><?php the_title(); ?></h1>
    </div>
</div>
<div class="bottom-content">
	<div class="container">
    	<div class="top-section">
        	<?php the_content(); ?>
		</div>	
    </div>
</div>
<?php 
endwhile; // End of the loop.

get_footer();
