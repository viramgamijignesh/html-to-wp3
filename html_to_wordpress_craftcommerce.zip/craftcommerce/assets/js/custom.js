jQuery( document ).ready(function() {

jQuery("#myList .blog-single").slice(0, 4).show();
    jQuery("#loadMore").on('click', function (e) {
        e.preventDefault();
        jQuery("#myList .blog-single:hidden").slice(0, 4).slideDown();
        if (jQuery("#myList .blog-single:hidden").length == 0) {
            jQuery("#loadMore").fadeOut('slow');
      jQuery('#loadMore').hide();
        }   
});
});